# Active Directory Lab Environment - Terraform
Consists of a single domain controller and client. NOT FOR PRODUCTION USE

Usage:
```
az login
az account set --subscription SUBSCRIPTIONID

terraform init

terraform plan

terraform apply

terraform destroy
```